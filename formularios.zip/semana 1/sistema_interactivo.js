
// ACTIVIDAD DE VALIDACIÓN DE DATOS



document.getElementById("sendbutton").addEventListener( "click", function (){

    const nombre = document.getElementById("nameDate").value;
    let edad = document.getElementById("ageDate").value;

    edad = parseInt(edad);

    if (edad > 18 && edad < 100 ){
        document.getElementById('mensaje').textContent=`Hola ${nombre}, Eres mayor de edad. ¡Preparate para grandes oportunidasdes en el mundo de la programación!`;
    } 
    else if (edad < 18) {
        document.getElementById('mensaje').textContent= `hola ${nombre}, eres menor de edad . ¡Sigue aprendiendo y disfrutando del codigo!`;

   
    }

    else {
        document.getElementById('mensaje').textContent= "Erro: por favor, ingrese una edad valida en numeros.";
    }


}); 